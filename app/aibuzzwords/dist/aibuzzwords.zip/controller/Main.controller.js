sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("aibuzzwords.controller.Main",{onInit:function(){}})});
//# sourceMappingURL=Main.controller.js.map